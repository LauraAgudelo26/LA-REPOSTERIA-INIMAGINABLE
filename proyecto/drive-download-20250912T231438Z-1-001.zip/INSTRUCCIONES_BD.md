# 🗄️ INSTRUCCIONES PARA CREAR LA BASE DE DATOS

## 📋 **PASOS PARA EJECUTAR EN PHPMYADMIN**

### 1. **Abrir phpMyAdmin**
- Ve a: `http://localhost/phpmyadmin`
- Usuario: `root` (sin contraseña por defecto en Laragon)

### 2. **Crear Base de Datos**
- Click en "Nueva" en el panel izquierdo
- Nombre: `placeres_ocultos`
- Cotejamiento: `utf8mb4_unicode_ci`
- Click "Crear"

### 3. **Ejecutar Script SQL**
- Selecciona la base de datos `placeres_ocultos`
- Ve a la pestaña "SQL"
- Abre el archivo `BASE_DE_DATOS_FINAL.sql`
- Copia TODO el contenido
- Pega en el área de texto de phpMyAdmin
- Click "Continuar"

### 4. **Verificar Creación**
Deberías ver estas tablas creadas:
- ✅ `cliente` (con usuarios admin y cliente)
- ✅ `categoria` (5 categorías)
- ✅ `producto` (10 productos)
- ✅ `pedido` (tabla vacía)
- ✅ `pedido_detalle` (tabla vacía)

## 🔑 **USUARIOS DE PRUEBA CREADOS**

### **Administrador**
- **Email**: `admin@placeresocultos.com`
- **Contraseña**: `admin123`
- **Rol**: `admin`

### **Cliente**
- **Email**: `cliente@test.com`
- **Contraseña**: `cliente123`
- **Rol**: `cliente`

## 🚨 **SI HAY ERRORES**

### Error: "Tabla ya existe"
```sql
-- Ejecuta esto primero para limpiar:
SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS pedido_detalle;
DROP TABLE IF EXISTS pedido;
DROP TABLE IF EXISTS producto;
DROP TABLE IF EXISTS categoria;
DROP TABLE IF EXISTS cliente;
SET FOREIGN_KEY_CHECKS = 1;
```

### Error: "Charset no soportado"
- Cambia `utf8mb4_unicode_ci` por `utf8_general_ci`
- O ejecuta línea por línea

### Error: "Foreign Key"
- Ejecuta primero las tablas sin relaciones
- Luego agrega las relaciones con ALTER TABLE

## ✅ **VALIDACIÓN**

Después de ejecutar, verifica:

```sql
-- Ver usuarios creados
SELECT id, nombre, email, rol FROM cliente;

-- Ver categorías
SELECT id, nombre FROM categoria;

-- Ver productos
SELECT id, nombre, precio FROM producto;
```

## 🔄 **SIGUIENTE PASO**

Una vez creada la base de datos, ve a:
`http://localhost/PAGINA/test_db_connection.php`

Para verificar que la conexión funciona correctamente.

---

**Archivo a usar**: `BASE_DE_DATOS_FINAL.sql`
**Contraseñas hasheadas**: ✅ Generadas correctamente
**Compatibilidad**: ✅ phpMyAdmin y MySQL 5.7+
