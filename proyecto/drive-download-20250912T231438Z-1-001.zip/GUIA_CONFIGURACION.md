# INSTRUCCIONES PARA CONFIGURAR LA TIENDA

## 1. CONFIGURACIÓN DE LA BASE DE DATOS

### Paso 1: Crear la base de datos
1. Abre phpMyAdmin o tu cliente MySQL preferido
2. Ejecuta el archivo `database_schema.sql` para crear la estructura completa
3. Luego ejecuta `insertar_productos_reales.sql` para cargar todos los productos

### Paso 2: Configurar conexión
1. Abre el archivo `config_db.php`
2. Modifica las constantes según tu configuración:
   ```php
   define('DB_HOST', 'localhost'); // Tu servidor MySQL
   define('DB_USER', 'root');      // Tu usuario MySQL
   define('DB_PASS', '');          // Tu contraseña MySQL
   ```

## 2. ARCHIVOS PRINCIPALES DEL SISTEMA

### Frontend (HTML/PHP):
- `index.php` - Página principal (copia de index.html)
- `productos.php` - Catálogo de productos conectado a la BD
- `iniciar_sesion.php` - Formulario de login funcional
- `registrarse.html` - Formulario de registro (ya conectado)

### Backend (PHP):
- `config_db.php` - Configuración y funciones de base de datos
- `controlador_productos.php` - Manejo de productos y API
- `procesar_login.php` - Autenticación y sesiones
- `guardar_usuario.php` - Registro de usuarios
- `enviar_recuperacion.php` - Sistema de recuperación de contraseña

## 3. FUNCIONALIDADES IMPLEMENTADAS

### ✅ Sistema de Usuarios:
- Registro de nuevos usuarios
- Login con validación
- Sesiones seguras
- Función "Recordarme"
- Recuperación de contraseña por email

### ✅ Catálogo de Productos:
- Productos cargados desde la base de datos
- Filtros por categoría
- Búsqueda de productos
- Información de stock
- Precios formateados
- Imágenes mapeadas automáticamente

### ✅ Base de Datos:
- 24 productos reales basados en tus imágenes
- 5 categorías: Postres, Bebidas, Frutas, Pasteles Especiales, Galletas
- Sistema de stock
- Procedimientos almacenados
- Vistas optimizadas

## 4. CÓMO USAR EL SISTEMA

### Para probar el sistema:
1. Ejecuta los scripts SQL en orden
2. Coloca los archivos en tu servidor web (XAMPP, WAMP, etc.)
3. Accede a `productos.php` para ver el catálogo
4. Registra un usuario en `registrarse.html`
5. Inicia sesión en `iniciar_sesion.php`

### URLs importantes:
- `productos.php` - Ver todos los productos
- `productos.php?categoria=1` - Filtrar por categoría
- `productos.php?buscar=churros` - Buscar productos
- `controlador_productos.php?api=productos` - API JSON de productos

## 5. PRODUCTOS INCLUIDOS

### Postres (8 productos):
- Cheesecake de Fresa Delicioso ($28,000)
- Churros Tradicionales ($8,500)
- Donas Glaseadas ($5,500)
- Postre de Gelatina ($6,500)
- Postre de Limón ($9,500)
- Postre de Oreo ($11,000)
- Rollos de Canela ($9,000)
- Cuca Tradicional ($15,000)

### Frutas (6 productos):
- Fresas con Crema ($12,500)
- Fresas con Marshmallow ($14,000)
- Banano Fresco ($3,500)
- Cerezas Selectas ($18,000)
- Manzanas Rojas ($4,500)
- Uvas Frescas ($8,000)

### Pasteles Especiales (6 productos):
- Torta para Despedida de Soltera ($95,000)
- Mini Tarta de Frutas ($16,500)
- Funny Birthday Cake ($75,000)
- Galletas de Sujetadores y Tangas ($25,000)
- Lingerie Cake ($120,000)
- Torta Fálica ($85,000)

### Galletas (1 producto):
- Galletas con Chips de Chocolate ($4,500)

### Bebidas (2 productos):
- Cappuccino Artesanal ($7,500)
- Bebidas Refrescantes ($6,000)

## 6. PRÓXIMOS PASOS SUGERIDOS

### Funcionalidades por implementar:
- Sistema de carrito de compras
- Procesamiento de pedidos
- Panel de administración
- Sistema de pagos
- Gestión de inventario
- Notificaciones por email

### Para más funcionalidades:
- Revisa los procedimientos almacenados en la BD
- Usa la clase `DatabaseConnection` para nuevas funciones
- Aprovecha la API REST en `controlador_productos.php`

## 7. SEGURIDAD IMPLEMENTADA

- Contraseñas hasheadas con password_hash()
- Validación de datos de entrada
- Protección contra SQL injection (PDO)
- Sesiones seguras
- Logging de actividades
- Tokens para recuperación de contraseña

¡El sistema está listo para usar! Solo ejecuta los scripts SQL y comienza a probar.
