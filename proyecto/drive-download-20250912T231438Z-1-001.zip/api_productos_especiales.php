<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET');
header('Access-Control-Allow-Headers: Content-Type');

require_once 'config_db.php';

try {
    $db = DatabaseConnection::getInstance();
    $pdo = $db->getConnection();
    
    // Consultar productos especiales (categoría 2 - Tortas Especiales)
    $sql = "SELECT 
                p.id,
                p.nombre,
                p.descripcion,
                p.precio,
                p.stock,
                p.imagen,
                p.destacado,
                c.nombre as categoria
            FROM producto p
            JOIN categoria c ON p.categoria_id = c.id
            WHERE c.id = 2 AND p.activo = 1 AND p.stock > 0
            ORDER BY p.precio DESC";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $productos = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Verificar que las imágenes existen y asignar imagen por defecto si es necesario
    foreach ($productos as &$producto) {
        // Si no tiene imagen en la BD, asignar una basada en el nombre
        if (empty($producto['imagen'])) {
            $nombre = strtolower($producto['nombre']);
            if (strpos($nombre, 'chocolate') !== false) {
                $producto['imagen'] = 'funny birthday cake.jpg';
            } else {
                $producto['imagen'] = 'pichos.jpeg';
            }
        }
        
        $rutaImagen = __DIR__ . '/img/' . $producto['imagen'];
        if (!file_exists($rutaImagen)) {
            // Si la imagen no existe, usar una imagen por defecto
            $producto['imagen'] = 'funny birthday cake.jpg';
        }
        
        // Formatear precio
        $producto['precio_formateado'] = number_format($producto['precio'], 0, ',', '.');
        $producto['destacado'] = (bool)$producto['destacado'];
    }
    
    echo json_encode([
        'success' => true,
        'productos' => $productos,
        'total' => count($productos)
    ]);
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Error al cargar productos especiales: ' . $e->getMessage(),
        'productos' => []
    ]);
}
?>
