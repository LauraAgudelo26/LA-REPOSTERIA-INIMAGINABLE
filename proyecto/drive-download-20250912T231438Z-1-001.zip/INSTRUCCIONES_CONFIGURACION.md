# 🚀 INSTRUCCIONES DE CONFIGURACIÓN DEL SISTEMA

## 📋 Requisitos Previos
- XAMPP o servidor local con PHP y MySQL
- Navegador web

## 🗃️ Configuración de la Base de Datos

### 1. Crear la Base de Datos
```sql
1. Abre phpMyAdmin (http://localhost/phpmyadmin)
2. Ejecuta el archivo: database_schema.sql
3. Esto creará la base de datos 'tienda_productos' con todas las tablas
```

### 2. Configurar Conexión
Edita el archivo `config_db.php` y cambia estos valores:
```php
define('DB_HOST', 'localhost');     // Tu servidor MySQL
define('DB_NAME', 'tienda_productos'); // Nombre de la base de datos
define('DB_USER', 'root');          // Tu usuario MySQL
define('DB_PASS', '');              // Tu contraseña MySQL
```

## 🔧 Archivos Creados/Actualizados

### ✅ Base de Datos
- `database_schema.sql` - Script completo de la base de datos
- `config_db.php` - Configuración y funciones de conexión

### ✅ Sistema de Recuperación de Contraseñas
- `enviar_correo.php` - Procesa solicitudes de recuperación (MODO CONSOLA)
- `restablecer_contraseña.php` - Formulario para nueva contraseña
- `procesar_nueva_password.php` - Actualiza la contraseña en BD

### ✅ Sistema de Registro
- `guardar_usuario.php` - Formulario y procesamiento de registro

## 🎯 Cómo Usar el Sistema

### 1. Registro de Usuarios
```
1. Ve a: guardar_usuario.php
2. Llena el formulario
3. El usuario se guarda en la tabla Cliente
```

### 2. Recuperación de Contraseñas - MODO SEGURO (Recomendado)
```
1. Ve a: recuperar_contra.html
2. Ingresa CUALQUIER email (no importa si existe o no)
3. Revisa el archivo: correos_log.txt para ver el código de 6 caracteres
4. Ve a: restablecer_contraseña_seguro.php
5. Ingresa el código de 6 caracteres + el email
6. Establece la nueva contraseña
```

### 3. Recuperación de Contraseñas - Modo Consola (Original)
```
1. Ve a: recuperar_contra.html
2. Ingresa un email registrado
3. Revisa el archivo: correos_log.txt
4. Copia el enlace de recuperación mostrado en el log
5. Pega el enlace en el navegador
6. Establece la nueva contraseña
```

## 📝 Logs del Sistema

### Archivo: `correos_log.txt`
Registra todo el proceso de recuperación:
```
[2025-09-01 14:30:15] === PROCESO DE RECUPERACIÓN INICIADO ===
[2025-09-01 14:30:15] 📧 Correo solicitante: usuario@ejemplo.com
[2025-09-01 14:30:15] 🔑 Código generado: AB1C2D
[2025-09-01 14:30:15] 🎫 Token generado: a1b2c3d4e5f6789
[2025-09-01 14:30:15] 🔗 Enlace: http://localhost/PAGINA/restablecer_contraseña_seguro.php?token=a1b2c3d4e5f6789
```

### Archivo: `codigos_recuperacion.json`
Almacena todos los códigos generados con detalles:
```json
[
  {
    "correo": "usuario@ejemplo.com",
    "codigo": "AB1C2D",
    "token": "a1b2c3d4e5f6789",
    "enlace": "http://localhost/PAGINA/restablecer_contraseña_seguro.php?token=a1b2c3d4e5f6789",
    "fecha_generacion": "2025-09-01 14:30:15",
    "fecha_expiry": "2025-09-02 14:30:15",
    "usado": false
  }
]
```

### Archivo: `cambios_password.json`
Registra todos los cambios de contraseña realizados.

### Archivo: `sistema_log.txt`
Registra actividades generales del sistema.

## 🗂️ Estructura de la Base de Datos

### Tablas Principales:
- **Cliente** - Usuarios registrados con tokens de recuperación
- **Producto** - Catálogo de productos
- **Categoria** - Categorías de productos
- **Pedido** - Órdenes de compra
- **DetallePedido** - Items de cada pedido
- **Proveedor** - Proveedores
- **Compra** - Compras a proveedores

### Datos de Ejemplo Incluidos:
- 5 categorías (Postres, Bebidas, Frutas, etc.)
- 10 productos (basados en tus imágenes)
- 3 clientes de prueba
- 3 pedidos de ejemplo

## 🔑 Funciones Importantes

### Procedimientos Almacenados:
- `RegistrarCliente()` - Registrar nuevo usuario
- `GenerarTokenRecuperacion()` - Crear token para recuperar contraseña
- `VerificarToken()` - Validar token de recuperación
- `ActualizarPassword()` - Cambiar contraseña

### Vistas:
- `vista_productos_categoria` - Productos con sus categorías
- `vista_pedidos_completos` - Pedidos con datos del cliente

## 🚨 Modo de Desarrollo Actual

**RECUPERACIÓN DE CONTRASEÑAS - MODO SEGURO:**
- ✅ **SIEMPRE genera código** para cualquier email (exista o no)
- ✅ **Código de 6 caracteres** fácil de usar (ej: AB1C2D)
- ✅ **No revela** si un email está registrado o no (más seguro)
- ✅ Todo se registra en archivos de log y JSON
- ✅ Intenta actualizar BD si el email existe
- ✅ Funciona sin configuración SMTP
- ✅ Perfecto para desarrollo y producción

**ARCHIVOS GENERADOS:**
- `correos_log.txt` - Log detallado de todo el proceso
- `codigos_recuperacion.json` - Base de datos de códigos en archivo
- `cambios_password.json` - Historial de cambios de contraseña

**Para activar envío real de correos:**
1. Configura tu servidor SMTP en `enviar_correo_seguro.php`
2. Reemplaza la función de logging por envío real

## 📧 Emails de Prueba Incluidos

Para probar la recuperación de contraseñas, usa estos emails:
- maria@email.com
- carlos@email.com  
- ana@email.com

## 🔍 Verificación del Sistema

### 1. Comprobar Base de Datos:
```sql
SELECT COUNT(*) FROM Cliente;
SELECT COUNT(*) FROM Producto;
SELECT * FROM vista_productos_categoria LIMIT 5;
```

### 2. Probar Registro:
- Ve a `guardar_usuario.php`
- Registra un usuario nuevo
- Verifica que aparezca en la tabla Cliente

### 3. Probar Recuperación:
- Ve a `recuperar_contra.html`
- Usa un email registrado
- Revisa `correos_log.txt` para el enlace
- Sigue el enlace y cambia la contraseña

## 🎉 ¡Sistema Listo!

Tu sistema ahora tiene:
- ✅ Base de datos completa y relacional
- ✅ Registro de usuarios con validaciones
- ✅ Recuperación de contraseñas funcional
- ✅ Logging completo para debugging
- ✅ Estructura escalable para e-commerce

**¡Todo funciona en modo consola para desarrollo sin necesidad de configurar SMTP!**
